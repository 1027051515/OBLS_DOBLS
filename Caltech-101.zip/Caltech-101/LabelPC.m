function [train_y, test_y]=LabelPC(T_train, T_test)

batch_num=1;
sorted_target=sort(cat(2,T_train',T_test'),2);
TrainingNO_save=size(T_train,1);
TestingNO=size(T_test,1);

label=zeros(1,1);                               %Find and save in 'label' class label from training and testing data sets
label(1,1)=sorted_target(1,1);
j=1;
for i = 2:size(sorted_target,2)
    if sorted_target(1,i) ~= label(1,j)
        j=j+1;
        label(1,j) = sorted_target(1,i);
    end
end
OutputNO=j;
%%%%%%%%%% Processing the targets of training
temp_T=zeros(TrainingNO_save, OutputNO);    %get the expect result of the training data.���?T����
for i = 1:TrainingNO_save
    for j = 1:OutputNO
        if label(1,j) == T_train(i,1)
            break;
        end
    end
    temp_T(i,j)=1;
end
T_train=temp_T;
%%%%%%%%%% Processing the targets of testing
temp_TV_T=zeros(TestingNO, OutputNO);   %get the expect result of the testing data.
for i = 1:TestingNO
    for j = 1:OutputNO
        if label(1,j) == T_test(i,1)
            break;
        end
    end
    temp_TV_T(i,j)=1;
end
T_test=temp_TV_T;
train_y=T_train*2-1;
test_y=T_test*2-1;
end