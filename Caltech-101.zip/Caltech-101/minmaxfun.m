function [Training1, Testing1]=minmaxfun(Training,Testing)

F=[Training(:,2:end);Testing(:,2:end)];
NO=size(Training,1);

F=mapminmax(F',-1,1);
F=F';

Training1=F(1:NO,:);
Testing1=F(NO+1:end,:);

end