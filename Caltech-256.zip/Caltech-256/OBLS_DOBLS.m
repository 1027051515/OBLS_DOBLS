%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%This is the demo for the OBLS and DOBLS on Caltech-256 dataset
%%%%%%The input feature is InceptionNet-v3 Feature
clear; 
warning off all;
format compact;

addpath(genpath('\MYCODE'));


tr_sum=0;te_sum=0;
CC=2^6;
C_all = [CC,CC,CC,CC,CC,CC,CC,CC,CC]; s=1;
rate = [1 0.8 0.5 0.5 0.5 0.2 0.2 0.2 0.2 0.2];
ijk=0;%the selection of the dataset
N11=5;%feature nodes  per window
N2=100;%number of windows of feature nodes
N33=500; %number of enhancement nodes
epochs=10;% number of epochs

%% Load the dataset
load Caltech256_inc_lfi_tes5f_da.mat;
load Caltech256_inc_lfi_tra5f_da.mat;
T_train=trainingFeatures(:,1);
T_test=testingFeatures(:,1);
[X_train,X_test]=minmaxfun(trainingFeatures,testingFeatures);
[train_y, test_y]=LabelPC(T_train,T_test);
train_x=X_train;
test_x=X_test;


train_err=zeros(1,epochs);test_err=zeros(1,epochs);train_time=zeros(1,epochs);test_time=zeros(1,epochs);
N1=N11; N3=N33; T = result(train_y);Te = result(test_y);T_p = train_y;Te_p = test_y;train_input=train_x;test_input=test_x;


%% DOBLS stcaks multiple OBLS.
train_y=T_p;  test_y=Te_p;
train_input=train_x;
test_input=test_x;
Tr_Acc=[];Te_Acc=[];tr_y_previous=0;te_y_previous=0;
for j=1:8    
     C=C_all(j);
    [tr_y, te_y, tr_hidden, te_hidden, Tr_Acc, Te_Acc] = bls_train_ours_stacked(train_input,train_y,test_input,test_y,s,C,N1,N2,N3,'E=T-Y',T_p,Te_p,tr_y_previous,te_y_previous,Tr_Acc,Te_Acc,'no','no',j); %OBLS
    tr_y=rate(j)*tr_y;
    te_y=rate(j)*te_y;

    train_y=train_y-tr_y;
    test_y=test_y-te_y;
    tr_y_previous=tr_y_previous+tr_y;
    te_y_previous=te_y_previous+te_y;


    %% [1] Subnet-based AE
    subnet_AE;
end
Te_Acc